#' Dummy data for lmdu example
#'
#'
#' @format A data frame with 234 observations on the following variables:
#' \describe{
#'   \item{\code{Y1}}{Dichotomous variable 1.}
#'   \item{\code{Y2}}{Dichotomous variable 2.}
#'   \item{\code{Y3}}{Dichotomous variable 3.}
#'   \item{\code{Y4}}{Dichotomous variable 4.}
#'   \item{\code{Y5}}{Dichotomous variable 5.}
#'   \item{\code{Y6}}{Dichotomous variable 6.}
#'   \item{\code{Y7}}{Dichotomous variable 7.}
#'   \item{\code{Y8}}{Dichotomous variable 8.}
#'   \item{\code{X1}}{Continuous variale 1.}
#'   \item{\code{X2}}{Continuous variale 2.}
#'   \item{\code{X3}}{Continuous variale 3.}
#'   \item{\code{X4}}{Continuous variale 4.}
#'   \item{\code{X5}}{Continuous variale 5.}
#'  }
#'
"dataExample_lmdu"
