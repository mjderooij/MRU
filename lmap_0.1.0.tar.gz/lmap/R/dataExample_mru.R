#' Dummy data for mru example
#'
#'
#' @format A data frame with 234 observations on the following variables:
#' \describe{
#'   \item{\code{y}}{Categorical variable.}
#'   \item{\code{X1}}{Continuous variale 1.}
#'   \item{\code{X2}}{Continuous variale 2.}
#'   \item{\code{X3}}{Continuous variale 3.}
#'   \item{\code{X4}}{Continuous variale 4.}
#'   \item{\code{X5}}{Continuous variale 5.}
#'  }
#'
"dataExample_mru"
